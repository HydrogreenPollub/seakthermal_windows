SeekOFix - portable application

Run TestSeek.exe on Windows with Microsoft .NET Framework 4.5 or newer.
Connect a compatible Seek Thermal camera with WinUSB installed for its iAP
USB interface (VID_289D, PID_0010).

The preview and exported PNG images include minimum, maximum, and center
readings along the bottom edge. The displayed Celsius values use the adjustable
sensor scale in the application, with 6360 sensor units set to 36 C by default.
The image is enlarged using AForge bicubic interpolation. Automatic contrast
range is enabled by default; use the range button to switch to manual sliders.
Optional AForge sharpening is off by default and can be enabled in the window.

AutoSave exports images to C:\seek\export. This folder is created when needed.

The package contains the application and its managed USB libraries. The
camera's WinUSB driver is not included and must already be installed on the PC.
AForge library notices and its LGPL license are included in this folder.